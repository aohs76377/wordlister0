PyInstaller PYZ archive: PYZ.pyz

sources/   recovered and packaged Python source
pyc/       the bytecode exactly as it was stored
resources/ everything else the archive carried

Recovered 820 bytecode file(s); decompiled 0; copied 0 packaged source file(s); 0 resource file(s); 0 decompilation failure(s).
Bytecode version: Python 3.13, read from the archive rather than from this worker.
Packaged .py files are copied unchanged and take precedence over a decompiled copy.
No uploaded Python code was executed, imported or unmarshalled into code objects.

PyInstaller PYZ archive holding 828 entries, frozen by Python 3.13.

8 namespace package entry/entries hold no code and were not written.

Python 3.13 bytecode is newer than this worker's pycdc support (through Python 3.10). The recovered .pyc files are under pyc/, but source decompilation was skipped to avoid misleading output.
